
<div class="large-3 columns no-pad service">

	<div class="service-image">

	<a href=" <?php get_post_permalink(); ?>"> <?php the_post_thumbnail(); ?> </a>

	<p class="title"><a href=" <?php get_post_permalink(); ?> "> <?php the_title(); ?></a></p>

	</div>

</div>
