
<div class="large-3 columns category">
	

	<div class="category-image-wrapper boxshadow">

		<div class="category-image" style="background-image: url( <?php echo the_post_thumbnail_url(); ?> )"></div> 

		<h3 class="title"><a href=" <?php the_permalink(); ?> "> <?php the_title(); ?></a></h3>

		<a class="link-title" href="<?php the_permalink(); ?>"></a>

	</div>

	 
	


</div>
